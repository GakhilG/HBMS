package com.capgemini.hbms.dao;

public interface QueryMapper {
	
	public static final String CHECK_VALID_USER="SELECT * FROM users WHERE email=? and password=?";
	public static final String ADD_USER_DETAILS=
			"INSERT INTO users VALUES(userid_seq.NEXTVAL,?,?,?,?,?,?,?)";
	public final static String ADD_HOTEL_DETAILS="Insert into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
	public final static String DELETE_HOTEL="delete from hotel where hotel_id=?";
	public final static String DISPLAY_HOTELDETAILS="select * from hotel";
	public final static String ADD_ROOM_DETAILS = "Insert into roomdetails values(?,seq_room_id.nextval,?,?,?,?)";
	public final static String DELETE_ROOM="delete from roomdetails where hotel_id=? and room_no=?";
	public final static String DISPLAY_ROOMDETAILS="select * from roomdetails where hotel_id=? and availability =?"; 
	public final static String UPDATE_HOTEL_description="update hotel set description=? where hotel_id=? ";
	public final static String UPDATE_HOTEL_price="update hotel set avg_rate_per_night=? where hotel_id=? ";
	public final static String ADD_BOOKING_DETAILS="insert into booking_details values(booking_seq_id.nextval,?,?,?,?,?,?,?)";
	public final static String GET_ROOM_PRICE="select per_night_rate from roomdetails where room_id=? and availability=?";
	public final static String GET_USER_ID="select user_id from users where email=?";
	public final static String GET_BOOKING_ID="select booking_id from booking_details where user_id=? and room_id=?";	
	public final static String CHANGE_AVAILABILITY="update roomdetails set availability=? where room_id=?";
	public final static String GET_BOOKING_DETAILS="select * from booking_details where user_id=?";
	public final static String GET_BOOKING_DETAILS_HOTEL="select * from booking_details where room_id in(select room_id from roomdetails where hotel_id=?)";
	public final static String GET_BOOKING_DETAILS_DATE="select * from booking_details where booked_from=?";
	public final static String DISPLAY_ROOM="select * from roomdetails ";
	public final static String UPDATE_ROOM_PRICE="update roomdetails set per_night_rate=? where room_id=? ";
	public final static String UPDATE_ROOM_TYPE="update roomdetails set room_type=? where room_id=? ";
	public final static String CHECKING_HOTEL="select * from hotel where hotel_id=?";
}
