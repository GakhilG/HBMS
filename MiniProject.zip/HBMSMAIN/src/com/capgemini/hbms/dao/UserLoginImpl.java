package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;





import org.apache.log4j.Logger;

import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.ui.AdminScreen;
import com.capgemini.hbms.util.DBConnection;


public class UserLoginImpl implements IUserLogin{

	private static Logger myUILogger=Logger.getLogger(UserLoginImpl.class);

	@Override
	public boolean checkValidUser(String email, String password) 
	{

		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.CHECK_VALID_USER);


				){

			preparedStatement.setString(1,email);
			preparedStatement.setString(2,password);
			ResultSet rs=preparedStatement.executeQuery();
			if(rs.next()){
				myUILogger.info("valid user");
				return true;
			}else
			{
				myUILogger.error("invalid user");
				return false;
			}

		}catch(SQLException e){
			myUILogger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public boolean checkValidAdmin(String email, String password)
			throws HBMSException {

		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.CHECK_VALID_USER);
				){

			preparedStatement.setString(1,email);
			preparedStatement.setString(2,password);
			ResultSet rs=preparedStatement.executeQuery();
			if(rs.next()){
				if(rs.getString("role").equals("admin")){
					myUILogger.info("valid admin");
					return true;
				}
				else
					myUILogger.error("invalid column");
			}else
			{
				myUILogger.info("invalid admin");
				return false;
			}
		}catch(SQLException e){

			myUILogger.error(e.getMessage());
			throw new HBMSException("Technical error refer log");
		}
		return false;
	}

	@Override
	public Integer getUserId(String email) throws HBMSException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.GET_USER_ID);


				){

			preparedStatement.setString(1,email);

			ResultSet rs=preparedStatement.executeQuery();
			if(rs.next()){
				myUILogger.info("user id fetched");
				return rs.getInt(1);
			}else
			{
				return null;
			}

		}catch(SQLException e){
			myUILogger.error(e.getMessage());
			throw new HBMSException("Technical error refer log");
		}

	}

}
