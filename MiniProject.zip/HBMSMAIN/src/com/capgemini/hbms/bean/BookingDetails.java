package com.capgemini.hbms.bean;

import java.time.LocalDate;

public class BookingDetails {
	private Integer booking_id;
	private Integer room_id;
	private Integer user_id;
	private LocalDate booked_from;
	private LocalDate booked_to;
	private Integer no_of_adults;
	private Integer no_of_children;
	private Double amount;
	public BookingDetails(Integer room_id, Integer user_id,
			LocalDate booked_from, LocalDate booked_to, Integer no_of_adults,
			Integer no_of_children, Double amount) {
		super();
		this.room_id = room_id;
		this.user_id = user_id;
		this.booked_from = booked_from;
		this.booked_to = booked_to;
		this.no_of_adults = no_of_adults;
		this.no_of_children = no_of_children;
		this.amount = amount;
	}
	public BookingDetails(Integer booking_id, Integer room_id, Integer user_id,
			LocalDate booked_from, LocalDate booked_to, Integer no_of_adults,
			Integer no_of_children, Double amount) {
		super();
		this.booking_id = booking_id;
		this.room_id = room_id;
		this.user_id = user_id;
		this.booked_from = booked_from;
		this.booked_to = booked_to;
		this.no_of_adults = no_of_adults;
		this.no_of_children = no_of_children;
		this.amount = amount;
	}
	public BookingDetails() {
		// TODO Auto-generated constructor stub
	}
	public Integer getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(Integer booking_id) {
		this.booking_id = booking_id;
	}
	public Integer getRoom_id() {
		return room_id;
	}
	public void setRoom_id(Integer room_id) {
		this.room_id = room_id;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public LocalDate getBooked_from() {
		return booked_from;
	}
	public void setBooked_from(LocalDate booked_from) {
		this.booked_from = booked_from;
	}
	public LocalDate getBooked_to() {
		return booked_to;
	}
	public void setBooked_to(LocalDate booked_to) {
		this.booked_to = booked_to;
	}
	public Integer getNo_of_adults() {
		return no_of_adults;
	}
	public void setNo_of_adults(Integer no_of_adults) {
		this.no_of_adults = no_of_adults;
	}
	public Integer getNo_of_children() {
		return no_of_children;
	}
	public void setNo_of_children(Integer no_of_children) {
		this.no_of_children = no_of_children;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "BookingDetails [booking_id=" + booking_id + ", room_id="
				+ room_id + ", user_id=" + user_id + ", booked_from="
				+ booked_from + ", booked_to=" + booked_to + ", no_of_adults="
				+ no_of_adults + ", no_of_children=" + no_of_children
				+ ", amount=" + amount + "]";
	}
	

}
