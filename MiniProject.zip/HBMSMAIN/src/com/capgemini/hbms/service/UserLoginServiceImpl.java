package com.capgemini.hbms.service;


import com.capgemini.hbms.dao.IUserLogin;
import com.capgemini.hbms.dao.UserLoginImpl;
import com.capgemini.hbms.exception.HBMSException;

public class UserLoginServiceImpl implements IUserLoginService {
	IUserLogin userDao=new UserLoginImpl();

	

	@Override
	public boolean checkValidUser(String email, String password)
			throws HBMSException {
		
		return userDao.checkValidUser(email, password);
	}

	@Override
	public boolean checkValidAdmin(String email, String password)
			throws HBMSException {
		return userDao.checkValidAdmin(email, password);
	}

	@Override
	public Integer getUserId(String email) throws HBMSException {
		
		return userDao.getUserId(email);
	}

}
