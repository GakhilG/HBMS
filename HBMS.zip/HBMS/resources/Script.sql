create table hotel(hotel_id varchar(4) primary key, city varchar(10), hotel_name varchar(20),
address varchar(25), description varchar(50), avg_rate_per_night number(10,2), phone_no1 varchar(10),
phone_no2 varchar(10), rating varchar(4), email varchar(15), fax varchar(15)); 

