package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.exception.HBMSException;


public interface IHotelService {

	Boolean addHotelDetails(Hotel hotel) throws HBMSException;

	void deleteHotelDetails(String hotelId1) throws HBMSException;




}

