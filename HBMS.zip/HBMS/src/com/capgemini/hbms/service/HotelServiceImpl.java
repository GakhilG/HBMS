package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.dao.HotelDaoImpl;
import com.capgemini.hbms.dao.IHotelDao;
import com.capgemini.hbms.exception.HBMSException;


public class HotelServiceImpl implements IHotelService{

	IHotelDao dao = new HotelDaoImpl();
	


	@Override
	public Boolean addHotelDetails(Hotel hotel) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.addHotelDetails(hotel);
	}



	@Override
	public void deleteHotelDetails(String hotelId1) throws HBMSException {
		dao.deleteHotelDetails(hotelId1);
		
	}



	
}
