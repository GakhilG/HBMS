package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class HotelDaoImpl implements IHotelDao{


	@Override
	public Boolean addHotelDetails(Hotel hotel) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.ADD_HOTEL_DETAILS);
										){
			
			preparestatement.setString(1, hotel.getHotelId());
			preparestatement.setString(2, hotel.getCity());
			preparestatement.setString(3, hotel.getHotelName());
			preparestatement.setString(4, hotel.getAddress());
			preparestatement.setString(5, hotel.getDescription());
			preparestatement.setDouble(6, hotel.getAvgRatePerNight());
			preparestatement.setString(7, hotel.getPhoneNo1());
			preparestatement.setString(8, hotel.getPhoneNo2());
			preparestatement.setString(9, hotel.getRating());
			preparestatement.setString(10, hotel.getEmail());
			preparestatement.setString(11, hotel.getFax());
			
			
			int i=preparestatement.executeUpdate();
			if(i>0){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deleteHotelDetails(String hotelId1) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.DELETE_HOTEL);)
										{
			preparestatement.setString(1,hotelId1);

			int i=preparestatement.executeUpdate();
			if(i>0){
				System.out.println("deleted");
			}else{
				System.out.println("Not deleted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
