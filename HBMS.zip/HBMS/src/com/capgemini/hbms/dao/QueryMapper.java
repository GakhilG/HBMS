package com.capgemini.hbms.dao;

public interface QueryMapper {

	public final static String ADD_HOTEL_DETAILS="Insert into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
	public final static String DELETE_HOTEL="delete from hotel where hotel_id=?";

}
