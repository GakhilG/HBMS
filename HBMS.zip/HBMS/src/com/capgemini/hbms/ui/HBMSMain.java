package com.capgemini.hbms.ui;

import java.util.Scanner;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IHotelService;

public class HBMSMain {


	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {

		IHotelService hotelService = new HotelServiceImpl();
		while(true){
			System.out.println("1.Add"
					+ "2.Delete"+"3.Update");
			int i=scanner.nextInt();
			switch (i) {
			case 1:
				System.out.println("Enter Hotel Id");
				String hotelId = scanner.next();
				System.out.println("Enter City");
				String city = scanner.next();
				System.out.println("Enter Hotel Name");
				String hotelName = scanner.next();
				System.out.println("Enter Hotel Address");
				String address = scanner.next();
				System.out.println("Enter description");
				String description = scanner.nextLine();
				scanner.nextLine();
				System.out.println("Enter amount per night");
				double avgRatePerNight = scanner.nextDouble();
				System.out.println("Enter phone number");
				String phoneNo1 = scanner.next();
				System.out.println("Enter another phone number");
				String phoneNo2 = scanner.next();
				System.out.println("Enter rating for hotel");
				String rating = scanner.next();
				System.out.println("Enter email Id");
				String email = scanner.next();
				System.out.println("Enter fax number");
				String fax = scanner.next();
			
				Hotel hotel = new Hotel(hotelId,city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
				try {
					Boolean boolean1 = hotelService.addHotelDetails(hotel);
				} catch (HBMSException e) {
					
					e.printStackTrace();
				}
				break;
			case 2:
				System.out.println("Enter hotelid to delete ");
				String hotelId1 = scanner.next();
				try {
					hotelService.deleteHotelDetails(hotelId1);
				} catch (HBMSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Enter hotelid to update price ");
				String hotelId2 = scanner.next();
				hotelService.updatePrice()
				break;
			default:
				break;
			}

		}
	}

}
