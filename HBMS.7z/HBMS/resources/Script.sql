create table hotel(hotel_id varchar(4) primary key, city varchar(10), hotel_name varchar(20),
address varchar(25), description varchar(50), avg_rate_per_night number(10,2), phone_no1 varchar(10),
phone_no2 varchar(10), rating varchar(4), email varchar(15), fax varchar(15)); 

create table RoomDetails(hotel_id varchar(4) references hotel(hotel_id),room_id int,
room_no varchar(3), room_type varchar(15),
per_night_rate number(6,2), availability varchar(15),primary key(hotel_id,room_no));

 create sequence seq_room_id
 minvalue 50
 maxvalue 999999999999
 start with 50
 increment by 1
 cache 20;