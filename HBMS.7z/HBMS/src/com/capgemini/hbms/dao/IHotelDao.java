package com.capgemini.hbms.dao;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.exception.HBMSException;

public interface IHotelDao {

	Boolean addHotelDetails(Hotel hotel) throws HBMSException;

	void deleteHotelDetails(String hotelId1) throws HBMSException;

	List<Hotel> displayHotelDetails() throws SQLException, HBMSException;

	void updatePrice(Double price, String hotelId2) throws HBMSException;

	void updateDescrption(String string, String hotelId2) throws HBMSException;

	
}
