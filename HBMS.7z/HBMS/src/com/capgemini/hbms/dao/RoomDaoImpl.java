package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class RoomDaoImpl implements IRoomDao {
	List<Room> roomList =new ArrayList<>();
	@Override
	public Boolean addRoomDetails(Room room) throws SQLException, HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.ADD_ROOM_DETAILS);
				){
			preparestatement.setString(1, room.getHotelId());
			preparestatement.setString(2, room.getRoomNo());
			preparestatement.setString(3, room.getRoomType());
			preparestatement.setDouble(4, room.getPernightRate());
			preparestatement.setString(5, room.getAvailability());
			
			int i=preparestatement.executeUpdate();
			if(i>0){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deleteRoomDetails(String hotelId1, String roomNo1) throws HBMSException {
		
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.DELETE_ROOM);
				){
			preparestatement.setString(1,hotelId1);
			preparestatement.setString(2,roomNo1);
			int i=preparestatement.executeUpdate();
			if(i>0){
				System.out.println("deleted");
			}else{
				System.out.println("Not deleted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

			

}

	@Override
	public List<Room> displayRoomDetails() throws SQLException, HBMSException {
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			
			ResultSet resultSet=statement.executeQuery(QueryMapper.DISPLAY_ROOMDETAILS);
			while(resultSet.next()){
				Room room=new Room();
				populateRoom(room,resultSet);
				roomList.add(room);
				
				
			}
			return roomList;
		
	}
	}

	private void populateRoom(Room room, ResultSet resultSet) throws SQLException {
	room.setHotelId(resultSet.getString("hotel_id"));
	room.setRoomId(resultSet.getInt("room_id"));
	room.setRoomNo(resultSet.getString("room_no"));
	room.setRoomType(resultSet.getString("room_type"));
	room.setPernightRate(resultSet.getDouble("per_night_rate"));
	room.setAvailability(resultSet.getString("availability"));
	
		
	}}