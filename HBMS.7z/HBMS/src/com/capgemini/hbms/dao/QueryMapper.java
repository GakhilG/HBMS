package com.capgemini.hbms.dao;

public interface QueryMapper {

	public final static String ADD_HOTEL_DETAILS="Insert into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
	public final static String DELETE_HOTEL="delete from hotel where hotel_id=?";
	public final static String DISPLAY_HOTELDETAILS="select * from hotel";
	public final static String ADD_ROOM_DETAILS = "Insert into roomdetails values(?,seq_room_id.nextval,?,?,?,?)";
	public final static String DELETE_ROOM="delete from roomdetails where hotel_id=? and room_no=?";
	public final static String DISPLAY_ROOMDETAILS="select * from roomdetails"; 
	public final static String UPDATE_HOTEL_description="update hotel set description=? where hotel_id=? ";
	public final static String UPDATE_HOTEL_price="update hotel set avg_rate_per_night=? where hotel_id=? ";
}
