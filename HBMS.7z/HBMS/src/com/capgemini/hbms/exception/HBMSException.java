package com.capgemini.hbms.exception;

public class HBMSException extends Exception{

	String msg;

	public HBMSException(String msg) {
		super();
		this.msg = msg;
	}

	public HBMSException() {
		super();
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "HBMSException [msg=" + msg + "]";
	}
	
}
