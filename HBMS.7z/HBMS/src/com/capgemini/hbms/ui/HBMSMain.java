package com.capgemini.hbms.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.RoomServiceImpl;

public class HBMSMain {



	private static Scanner scanner = new Scanner(System.in);

	static IRoomService roomService = new RoomServiceImpl();


	public static void main(String[] args) {
		List<Room> roomList=new ArrayList<>();
		List<Hotel> hotelList =new ArrayList<>();
		IHotelService hotelService = new HotelServiceImpl();
		while(true){
			System.out.println("1.Add"
					+ "2.Delete"+"3.Update "+"4.Display hotels");
			int i=scanner.nextInt();
			switch (i) {
			case 1:
				System.out.println("Enter Hotel Id");
				String hotelId = scanner.next();
				System.out.println("Enter City");
				String city = scanner.next();
				System.out.println("Enter Hotel Name");
				String hotelName = scanner.next();
				System.out.println("Enter Hotel Address");
				String address = scanner.next();
				System.out.println("Enter description");
				String description = scanner.nextLine();
				scanner.nextLine();
				System.out.println("Enter amount per night");
				double avgRatePerNight = scanner.nextDouble();
				System.out.println("Enter phone number");
				String phoneNo1 = scanner.next();
				System.out.println("Enter another phone number");
				String phoneNo2 = scanner.next();
				System.out.println("Enter rating for hotel");
				String rating = scanner.next();
				System.out.println("Enter email Id");
				String email = scanner.next();
				System.out.println("Enter fax number");
				String fax = scanner.next();

				Hotel hotel = new Hotel(hotelId,city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
				try {
					Boolean boolean1 = hotelService.addHotelDetails(hotel);
				} catch (HBMSException e) {

					e.printStackTrace();
				}
				break;
			case 2:
				System.out.println("Enter hotelid to delete ");
				String hotelId1 = scanner.next();
				try {
					hotelService.deleteHotelDetails(hotelId1);
				} catch (HBMSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Enter hotelid to update  ");
				String hotelId2 = scanner.next();
				System.out.println("Enter your option 1.price  2.Description  3.Hotel name");
				int j=scanner.nextInt();
				scanner.nextLine();
				System.out.println(" Enter Update value");
				String string=scanner.nextLine();
				switch(j){
				case 1:
					Double price=Double.parseDouble(string);
					try {
						hotelService.updatePrice(price,hotelId2);
					} catch (HBMSException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					//System.out.println("Updated");
					break;
				case 2:
					try {
						hotelService.updateDescrption(string,hotelId2);
					} catch (HBMSException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					break;
				case 3:
					break;
				}

				break;
			case 4:
				try {
					hotelList=hotelService.displayHotelDetails();
					showHotelDetails(hotelList);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (HBMSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;


			default:
				break;
			}

		}
	}
	private static void showHotelDetails(List<Hotel> hotelList) {
		for(Hotel h:hotelList){
			System.out.println(h);
		}

	}
	/*while(true){
			System.out.println("1.Add"
					+ "2.Delete"+"3.Update "+"4.Display hotels");
			int i=scanner.nextInt();
			switch (i) {
			case 1:
				System.out.println("Enter Hotel Id");
				String hotelId = scanner.next();
				//System.out.println("Enter roomId");
				//String roomId = scanner.next();
				System.out.println("Enter room no.");
				String roomNo = scanner.next();
				System.out.println("Enter roomtype");
				String roomType = scanner.next();
				System.out.println("Enter amount per night");
				Double pernightRate = scanner.nextDouble();
				System.out.println("Enter availability");
				String availability = scanner.next();
				scanner.nextLine();

				Room room=new Room(hotelId,roomNo,roomType,pernightRate,availability);

				try {
					Boolean boolean1 = roomService.addRoomDetails(room);
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (HBMSException e) {
					e.printStackTrace();
				}
				break;

			case 2:
				System.out.println("Enter hotelId to delete");
				String hotelId1=scanner.next();
				System.out.println("Enter roomNo to delete ");
				String roomNo1 = scanner.next();

				try {
					roomService.deleteRoomDetails(hotelId1,roomNo1);
				} catch (HBMSException e) {

					e.printStackTrace();
				}

				break;
			case 4: try {
					roomList=roomService.displayRoomDetails();
				} catch (SQLException e) {

					e.printStackTrace();
				} catch (HBMSException e) {

					e.printStackTrace();
				}
			showRoomDetails(roomList);

			default:
				break;
			}
		}
	}


	private static void showRoomDetails(List<Room> roomList) {
		for(Room r:roomList){
			System.out.println(r);
		}*/

}

