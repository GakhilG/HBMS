package com.capgemini.hbms.service;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.exception.HBMSException;

public interface IRoomService {

	Boolean addRoomDetails(Room room) throws SQLException, HBMSException;

	void deleteRoomDetails(String hotelId1, String roomNo1) throws HBMSException;

	List<Room> displayRoomDetails() throws SQLException, HBMSException;

	
}
