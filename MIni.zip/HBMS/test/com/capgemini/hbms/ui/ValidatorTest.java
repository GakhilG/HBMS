package com.capgemini.hbms.ui;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidatorTest {
	Validator validator = new Validator();

	@Test
	public void testIsValidDate() {
	assertTrue(validator.isValidDate("2018-10-31"));	
	}

}
