package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import oracle.net.aso.p;

import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class RoomDaoImpl implements IRoomDao{

	final static Logger roomlogger=Logger.getLogger(RoomDaoImpl.class);

	@Override
	public Boolean addRoomDetails(Room room) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.ADD_ROOM_DETAILS);
				){
			preparestatement.setInt(1, room.getHotelId());
			preparestatement.setString(2, room.getRoomNo());
			preparestatement.setString(3, room.getRoomType());
			preparestatement.setDouble(4, room.getPernightRate());
			preparestatement.setString(5, room.getAvailability());
			
			int i=preparestatement.executeUpdate();
			if(i>0){
				roomlogger.info("Room details has been added succefully!");
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			roomlogger.error("unable to add room details");
			//	e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deleteRoomDetails(Integer hotelId1, String roomNo1)
			throws HBMSException {

		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.DELETE_ROOM);
				){
			preparestatement.setInt(1,hotelId1);
			preparestatement.setString(2,roomNo1);
			int i=preparestatement.executeUpdate();
			if(i>0){
				roomlogger.info("succeflly room details are deleted");
				//System.out.println("deleted");
			}else{
				System.out.println("Not deleted");
			}
		} catch (SQLException e) {
			roomlogger.error("unable to delete room details");
			//e.printStackTrace();
		}
		
	}

	@Override
	public List<Room> displayRoomDetails() throws HBMSException {
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			
			ResultSet resultSet=statement.executeQuery(QueryMapper.DISPLAY_ROOM);
			List<Room> roomList=new ArrayList<>();
			while(resultSet.next()){
				Room room=new Room();
				room.setHotelId(resultSet.getInt("hotel_id"));
				room.setRoomId(resultSet.getInt("room_id"));
				room.setRoomNo(resultSet.getString("room_no"));
				room.setRoomType(resultSet.getString("room_type"));
				room.setPernightRate(resultSet.getDouble("per_night_rate"));
				room.setAvailability(resultSet.getString("availability"));
				roomList.add(room);
				
				
			}
			roomlogger.info(" available room details displayed");
			return roomList;
		}
			
			catch (SQLException e) {
				roomlogger.error("unable to display room details");
				//e.printStackTrace();
			}
			return null;
	}

	@Override
	public List<Room> displayRoomDetails(int hotel_id) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.DISPLAY_ROOMDETAILS);
				){
			preparestatement.setInt(1,hotel_id);
			preparestatement.setString(2,"yes");
			ResultSet resultSet=preparestatement.executeQuery();
			List<Room> roomList=new ArrayList<>();
			while(resultSet.next()){
				
				Room room=new Room();
				room.setHotelId(resultSet.getInt("hotel_id"));
				room.setRoomId(resultSet.getInt("room_id"));
				room.setRoomNo(resultSet.getString("room_no"));
				room.setRoomType(resultSet.getString("room_type"));
				room.setPernightRate(resultSet.getDouble("per_night_rate"));
				room.setAvailability(resultSet.getString("availability"));
				roomList.add(room);
			}
			roomlogger.info("room details are displayed");
			return roomList;
		} catch (SQLException e) {

			roomlogger.error("unable to display room details");
			//e.printStackTrace();
		}
		return null;
	}

	@Override
	public Double getPrice(Integer room_id) throws HBMSException {
		
		
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.GET_ROOM_PRICE);
				){
			preparestatement.setInt(1,room_id);
			preparestatement.setString(2,"yes");
			
			ResultSet resultSet=preparestatement.executeQuery();
			
			if(resultSet.next()){
				return resultSet.getDouble(1);
			}else{
				System.out.println("Room not available");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			roomlogger.error("rooms are not available");
			//e.printStackTrace();
		}
		return null;
		
		
	}

	@Override
	public void updateRoomPrice(int room_id, Double price) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.UPDATE_ROOM_PRICE);){
			
			preparestatement.setDouble(1, price);
			preparestatement.setInt(2, room_id);
			
			int i=preparestatement.executeUpdate();
			if(i>0){
				roomlogger.info("succefully room price got updated");
				//System.out.println("Updated");
			}else{
				System.out.println("Fail");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			roomlogger.error("unable to update room price");
			//e.printStackTrace();
		}
		
	}

	@Override
	public void updateType(int roomid, String type) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.UPDATE_ROOM_TYPE);){
			
			preparestatement.setString(1, type);
			preparestatement.setInt(2, roomid);
			
			int i=preparestatement.executeUpdate();
			if(i>0){
				roomlogger.info("room type got updated");
				//System.out.println("Updated");
			}else{
				System.out.println("Fail");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			roomlogger.error("rooom type doesnot updated ");
			//e.printStackTrace();
		}
		
	}

	@Override
	public boolean checkRoomNo(Integer hotelId, String roomNo) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.CHECKING_ROOM_NO);){
		
			preparestatement.setInt(1, hotelId);
			
			ResultSet resultSet=preparestatement.executeQuery();
			while(resultSet.next()){
	
				if(roomNo.equals(resultSet.getString("room_no")))
					return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return false;
	}

}
