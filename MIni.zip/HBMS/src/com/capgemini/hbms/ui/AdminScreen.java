package com.capgemini.hbms.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserLoginService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserLoginServiceImpl;

public class AdminScreen {
	public static IUserLoginService userService=new UserLoginServiceImpl();
	public static IHotelService hotelService=new HotelServiceImpl();
	static IRoomService roomService = new RoomServiceImpl();
	static IBookingService bookingService = new BookingServiceImpl();
	private static Logger myUILogger=Logger.getLogger(AdminScreen.class);
	public static Validator validator=new Validator();
	public static Scanner sc=new Scanner(System.in);
	public  boolean checkValidAdmin() {
		System.out.println("Enter your email:");
		String email=sc.next();
		if(validator.isValidEmail(email)){
			System.out.println("Enter your password:");
			String password=sc.next();
			if(validator.isValidPassword(password)){
				try {
					if(userService.checkValidAdmin(email,password)){
						System.out.println("Welcome Admin! ");
						return true;
					}
					else{
						System.out.println("You are invalid Admin");

						return false;
					}
				} catch (HBMSException e) {
					myUILogger.info(e.getMessage());
					System.out.println("please enter valid details");
					//e.printStackTrace();
				}	
			}else
				System.out.println("Enter valid Password");//password
		}else
			System.out.println("Enter valid Email Id");//email
		return false;
	}
	public Boolean addHotelDetails() {

		System.out.println("Enter Hotel Id:");
		Integer hotelId = sc.nextInt();
		if(hotelId>0){
			System.out.println("Enter amount per night:");
			double avgRatePerNight = sc.nextDouble();

			System.out.println("Enter City:");
			String city = sc.next();
			sc.nextLine();
			System.out.println("Enter Hotel Name:");
			String hotelName = sc.nextLine();
			System.out.println("Enter Hotel Address:");
			String address = sc.nextLine();
			System.out.println("Enter description:");
			String description = sc.nextLine();
			System.out.println("Enter 10 digit mobile number:");
			String phoneNo1 = sc.next();
			if(validator.isValidMobileNo(phoneNo1)){
				System.out.println("Enter 10 digit alternate mobile number:");
				String phoneNo2 = sc.next();
				if(validator.isValidMobileNo(phoneNo2)){
					if(phoneNo2.equals(phoneNo1)){
						System.out.println("Mobile Numbers should not be same");
					}else{
						System.out.println("Enter rating for hotel: [1-5]");
						String rating = sc.next();
						if(validator.isValidRating(rating)){
							System.out.println("Enter email Id:");
							String email = sc.next();
							if(validator.isValidEmail(email)){
								System.out.println("Enter fax number:");
								String fax = sc.next();

								Hotel hotel = new Hotel(hotelId,city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
								try {
									Boolean boolean1 = hotelService.addHotelDetails(hotel);
									return boolean1;

								}catch (InputMismatchException e) {
									//System.out.println("enter");
								}
								catch (HBMSException e) {

									e.printStackTrace();
								}

							}else{
								System.out.println("please enter valid email");
							}
						}else{
							System.out.println("Enter rating between 1-5 ");//rating
						}
					}
				}else{
					System.out.println("Please enter 10 digit valid mobile number");
				}
			}else{
				System.out.println("Enter valid mobile number");//phone 1
			}
		}else{
			System.out.println("Enter valid Hotel Id");//hotelid
		}

		return false;
	}
	public void deleteHotelDetails(){
		System.out.println("Enter hotelid to delete ");
		int hotelId1 = sc.nextInt();
		try {
			hotelService.deleteHotelDetails(hotelId1);
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void displayHotelDetails(){
		List<Hotel> hotelList =new ArrayList<>();
		try {
			hotelList=hotelService.displayHotelDetails();
			showHotelDetails(hotelList);
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private static void showHotelDetails(List<Hotel> hotelList) {
		for(Hotel h:hotelList){
			System.out.println(h);
		}

	}
	public Boolean addRoom() throws HBMSException{
		System.out.println("Enter Hotel Id");
		Integer hotelId = sc.nextInt();
		//System.out.println("Enter roomId");
		//String roomId = scanner.next();
		System.out.println("Enter room no:");
		String roomNo = sc.next();
		if(roomService.checkRoomNo(hotelId,roomNo)){
			System.out.println("Room Number already exists..please enter new room number");
		}else{
			System.out.println("Enter roomtype:[1.Non A/C Room, 2.A/C Room, 3.Executive A/C Room, 4.Deluxe A/C Room]");
			String roomType=null;
			boolean b = true;
			while(b){
				int type=sc.nextInt();
				switch(type) {
				case 1: roomType = "Non A/C";
				b=false;
				break;
				case 2: roomType = "A/C";
				b=false;
				break;
				case 3: roomType = "Executive A/C";
				b=false;
				break;
				case 4: roomType = "Deluxe A/C";
				b=false;
				break;
				default:

					System.out.println("Please enter valid option.");
					b=true;
					break;
				}
			}
			System.out.println("Enter amount per night");
			Double pernightRate = sc.nextDouble();
			System.out.println("Enter availability:[yes/no]");
			String availability = sc.next();
			if(validator.isValidAvailability(availability)){
				sc.nextLine();

				Room room=new Room(hotelId,roomNo,roomType,pernightRate,availability);

				try {
					Boolean boolean1 = roomService.addRoomDetails(room);
					return boolean1;
				} catch (HBMSException e) {
					e.printStackTrace();
				}
			}else{
				System.out.println("Entered availability data doesn't match ");
			}

		}
		return false;
	}

	public void deleteRoom(){
		System.out.println("Enter hotelId to delete:");
		Integer hotelId1=sc.nextInt();
		System.out.println("Enter roomNo to delete: ");
		String roomNo1 = sc.next();

		try {
			roomService.deleteRoomDetails(hotelId1,roomNo1);
		} catch (HBMSException e) {

			e.printStackTrace();
		}
	}
	public void getBookingDetails() {
		System.out.println("Enter hotel id :");
		int hotel_id=sc.nextInt();
		List<BookingDetails> bookingDetails=new ArrayList<>();
		try {
			bookingDetails=bookingService.getBookingDetails(hotel_id);
			if(bookingDetails!=null){
				for(BookingDetails details:bookingDetails){
					System.out.println(details);
				}
			}else
				System.out.println("No data found");
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	public void getBookingDetailsDate() {
		System.out.println("Enter specific date : (YYYY-MM-DD)");
		String fromDate=sc.next();
		if(validator.isValidDate(fromDate)){
			LocalDate fdate=LocalDate.parse(fromDate);
			List<BookingDetails> bookingDetails=new ArrayList<>();
			try {
				bookingDetails=bookingService.getBookingDetails(fdate);
				for(BookingDetails details:bookingDetails){
					System.out.println(details);
				}
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			System.out.println("date format is invalid");
		}

	}
	public void modifyHotelDetails() {
		System.out.println("1.Modify Hotel Description");
		System.out.println("2.Modify Hotel Price");
		int ch=sc.nextInt();
		switch(ch){
		case 1:
			System.out.println("Enter hotel id:");
			int hotel_id=sc.nextInt();
			System.out.println("Enter Description:");
			String description=sc.next();
			try {
				hotelService.updateDescrption(description, hotel_id);
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:
			System.out.println("Enter hotel id:");
			int hotelid=sc.nextInt();
			System.out.println("Enter Price:");
			Double price=sc.nextDouble();
			try {
				hotelService.updatePrice(price, hotelid);
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}

	}
	public void modifyRoomDetails() {
		List<Room> roomList=new ArrayList<>();
		System.out.println("1.Modify Room Price");
		System.out.println("2.Modify Room Type");
		int ch=sc.nextInt();
		switch(ch){
		case 1:


			try {
				roomList=roomService.displayRoomDetails();
				for(Room h:roomList){
					System.out.println(h);
				}
				System.out.println("Enter Room id:");
				int room_id=sc.nextInt();
				System.out.println("Enter Room price:");
				Double price=sc.nextDouble();
				roomService.updateRoomPrice(room_id,price);
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:
			System.out.println("Enter Room id:");
			int roomid=sc.nextInt();
			//System.out.println("Enter Room Type:");
			System.out.println("Enter roomtype:[1.Non A/C, 2.A/C, 3.Executive A/C, 4.Deluxe A/C]");
			String type=sc.next();
			try {
				roomService.updateType(roomid, type);
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}

	}


}
