package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.dao.IUserRegistration;
import com.capgemini.hbms.dao.UserRegistrationImpl;
import com.capgemini.hbms.exception.HBMSException;

public class UserRegistrationService implements IUserRegistrationService{

	private static IUserRegistration uReg=new UserRegistrationImpl();
	@Override
	public boolean registerUser(Users user) throws HBMSException {
		
		return uReg.registerUser(user);
	}

}
