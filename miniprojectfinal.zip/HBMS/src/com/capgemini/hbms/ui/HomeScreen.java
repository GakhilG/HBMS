package com.capgemini.hbms.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.hbms.exception.HBMSException;



public class HomeScreen {
	public static Scanner sc=new Scanner(System.in);
	static UserScreen userScreen=new UserScreen();
	static AdminScreen adminScreen=new AdminScreen();


	public static void main(String[] args) throws HBMSException {

		PropertyConfigurator.configure("resources/log4j.properties");

		System.out.println("\n\t\t\t***Welcome To Hotel Booking Management Application***");


		while(true){
			try{
				System.out.println("\n1.SIGNUP\n2.SIGNIN");
				int choice=sc.nextInt();
				switch(choice){
				case 1:  
					System.out.println("\n\t\t\t\t ***USER SCREEN***\n");
					userScreen.registerUser();
					break;

				case 2:
					boolean a =true;
					while(a){
						System.out.println("\n\t\t\t\t***LOGIN SCREEN***");
						System.out.println("1.Admin\n2.User/HotelEmployee\n3.Exit");

						int choice1=sc.nextInt();
						switch(choice1){
						case 3:

							a = false;
							break;

						case 2:
							try{
								System.out.println("Enter your email");
								String email=sc.next();
								System.out.println("Enter your password");
								String password=sc.next();


								if(userScreen.checkValidUser(email,password)){
									boolean b = true;
									while(b){
										System.out.println("1.Search Hotels");
										System.out.println("2.Book Hotels");
										System.out.println("3.View Booking Status");
										System.out.println("4.Exit");
										int choice2=sc.nextInt();
										switch(choice2){
										case 1:
											adminScreen.displayHotelDetails();
											break;

										case 2:								
											Integer bookId=userScreen.addBookingDetails();
											if(bookId>0)
												System.out.println("You have successfully booked a room. \n"
														+ " Generated Booking Id is: "+bookId);
											else
												System.out.println("");
											break;

										case 3:
											userScreen.getBookingDetails(email);
											break;
										case 4:
											System.out.println("Thank you");
											b=false;								
											break;
										}

									}
								}
							}catch(InputMismatchException e){
								System.out.println("Please enter valid option");
							}
							break;

						case 1:
							try{
								System.out.println("\n\t\t\t\t***ADMIN SCREEN***\n");
								if(adminScreen.checkValidAdmin()){
									boolean x=true;
									while(x){
										System.out.println("1.Hotel Management");
										System.out.println("2.Room Management");
										System.out.println("3.View Reports");
										System.out.println("4.Exit");
										int option=sc.nextInt();
										switch(option) {
										case 1:
											boolean c = true;
											while(c){
												System.out.println("1.Add Hotels");
												System.out.println("2.Delete Hotel");
												System.out.println("3.Modify Hotel");
												System.out.println("4.Exit");
												int inside1=sc.nextInt();
												switch(inside1){
												case 1:
													if(adminScreen.addHotelDetails())
														System.out.println("New Hotel Details has been added successfully!");

													break;
												case 2:
													adminScreen.deleteHotelDetails();
													break;
												case 3:adminScreen.modifyHotelDetails();
												break;
												case 4:
													c = false;										
													break;
												default:
													System.out.println("Enter Valid Option");
													break;
												}
											}
											break;
										case 2:
											boolean d = true;
											while(d){
												System.out.println("1.Add Room");
												System.out.println("2.Delete Room");
												System.out.println("3.Modify Room");
												System.out.println("4.Exit");
												int inside2=sc.nextInt();
												switch(inside2){
												case 1:
													if(adminScreen.addRoom())
														System.out.println("New Room added");
													else 
														System.out.println("Unable to add new room...");

													break;
												case 2:adminScreen.deleteRoom();;
												break;
												case 3:adminScreen.modifyRoomDetails();
												break;
												case 4:
													d = false;											
													break;
												default:
													System.out.println("Enter Valid Option");
													break;
												}
											}
											break;
										case 3:
											boolean e = true;
											while(e){
												System.out.println("1.View Booking Details of specific hotel");
												System.out.println("2.View Booking Details for specific date");
												System.out.println("3.View List of Hotels");
												System.out.println("4.Exit");
												int inside3=sc.nextInt();
												switch(inside3){
												case 1:
													adminScreen.getBookingDetails();
													break;
												case 2:
													adminScreen.getBookingDetailsDate();
													break;
												case 3:
													adminScreen.displayHotelDetails();
													break;
												case 4:
													e = false;											
													break;
												default:
													System.out.println("Enter Valid Option");
													break;
												}
											}
											break;
										case 4:						
											x=false;
											break;
										default:
											break;

										}
									}
								}					
							}catch(InputMismatchException e){
								System.out.println("Please enter valid option");
							}
						}break;
					}
				}
			}catch(InputMismatchException e){
				System.out.println("Please enter valid option");
			}
		}
	}
}



















/*int ch=sc.nextInt();
							switch(ch){
							case 1:if(adminScreen.addHotelDetails())
								System.out.println("success");
							break;
							case 2:adminScreen.deleteHotelDetails();
							break;
							case 3:adminScreen.displayHotelDetails();
							break;
							case 4:adminScreen.addRoom();
							break;
							case 5:adminScreen.deleteRoom();;
							break;
							case 6:

								adminScreen.getBookingDetails();
								break;
							case 7:

								adminScreen.getBookingDetailsDate();
								break;
							case 8:System.exit(0);
							break;
							}
						}
					}else{
						System.out.println("In Valid");

					}
					break;

				}


				break;
			case 3:
				System.exit(0);
				break;
			}

			}*/






