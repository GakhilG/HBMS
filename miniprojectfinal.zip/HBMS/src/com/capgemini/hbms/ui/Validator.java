package com.capgemini.hbms.ui;

public class Validator {
	public boolean isValidRole(String role) {

		if(role.equals("User")||role.equals("Employee"))
			return true;

		else return false;

	}

	public boolean isValidUserName(String user_name) {
		return user_name.matches("[a-zA-Z]{3,}");
	}

	public  boolean isValidMobileNo(String mobile_no) {

		return mobile_no.matches("[1-9]{1}[0-9]{9}");
	}

	public  boolean isValidEmail(String email) {

		return email.matches("[a-z]+@[a-z]+.[a-z]{2,3}");
	}

	public  boolean isValidPhoneNo(String phone) {
		return phone.matches("[1-9]{1}[0-9]{9}");

	}

	public  boolean isValidPassword(String password) {
		return  password.matches("[a-zA-Z]{7}");


	}

	public boolean isValidHotelId(Integer hotelId) {

		return hotelId.toString().matches("[0-9]{1,}");
	}

	public boolean isValidRating(String rating) {

		return rating.matches("[1-5]{1}");
	}
	public boolean isValidDate(String date) {

		//return date.matches("[0-9]{4}+-([01-12]{1,2})+-([01-31]{1,2})");
		
	return date.matches("[1-2][0-9]{3}[-]([1-9]|0[1-9]|1[0-2])[-]"
			+ "([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])");
	}

	public boolean isValidAvailability(String availability) {
		if(availability.equals("yes")||availability.equals("no"))
			return true;
		else
			return false;
	}



}
