package com.capgemini.hbms.bean;

public class Room {
	private Integer hotelId;
	private Integer roomId  ;
	private String roomNo;
	private String roomType;
	private Double pernightRate ;
	private String availability; 
	private String photo ;
	public Room(Integer hotelId, String roomNo, String roomType,
			Double pernightRate, String availability) {
		super();
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.pernightRate = pernightRate;
		this.availability = availability;
	}
	public Room(Integer hotelId, Integer roomId, String roomNo,
			String roomType, Double pernightRate, String availability,
			String photo) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.pernightRate = pernightRate;
		this.availability = availability;
		this.photo = photo;
	}
	public Room() {
		// TODO Auto-generated constructor stub
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public Integer getRoomId() {
		return roomId;
	}
	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public Double getPernightRate() {
		return pernightRate;
	}
	public void setPernightRate(Double pernightRate) {
		this.pernightRate = pernightRate;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	@Override
	public String toString() {
		return "Room [hotelId=" + hotelId + ", roomId=" + roomId + ", roomNo="
				+ roomNo + ", roomType=" + roomType + ", pernightRate="
				+ pernightRate + ", availability=" + availability + ", photo="
				+ photo + "]";
	}
	

}
