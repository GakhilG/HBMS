package com.capgemini.hbms.dao;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.BookingServiceImpl;

public class BookingDaoImplTest {
	static BookingServiceImpl booking=new BookingServiceImpl();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddBookingDetails() {
		BookingDetails bookingDetails=new BookingDetails();
		
		bookingDetails.setUser_id(46);
		bookingDetails.setRoom_id(73);
		bookingDetails.setBooked_from(LocalDate.parse("2018-11-12"));
		bookingDetails.setBooked_to(LocalDate.parse("2018-11-22"));
		bookingDetails.setNo_of_adults(2);
		bookingDetails.setNo_of_children(2);
		try {
			System.out.println(booking.addBookingDetails(bookingDetails));
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
